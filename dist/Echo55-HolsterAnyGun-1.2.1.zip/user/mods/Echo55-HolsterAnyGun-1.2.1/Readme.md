Just like the title says. Holster any gun in the pistol slot.

Enjoy

Echo55